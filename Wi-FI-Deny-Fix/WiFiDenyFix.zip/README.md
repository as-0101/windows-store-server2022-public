# WiFi Deny Fix — Windows Server 2022

Optional fix / Необязательное исправление.

Reconstructed from the reported successful experiment of 24 November 2026; not independently retested on Windows. Applies to the current user's wifiData consent, not just Microsoft Store. It does not disable Windows Firewall or modify WFP rules, HKLM, system binaries, or licensing. Do not use if the restriction is intentional or managed by your organization.

## Apply / Применение
1. Sign in as the affected Store user. Check the current value in Registry Editor under HKCU\Software\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\wifiData. This package targets the case where Value is a REG_SZ containing Deny. If the key/value is missing or different, do not apply this package.
2. Export that key as a personal backup before making changes. Import WiFiDenyFix.reg under the same user account (not another administrator account). Confirm Value is Allow. Restart Store and test network access.

## Rollback / Откат
WiFiDenyFix_Restore.reg restores the previously observed Deny value, not an arbitrary original configuration. Prefer importing your own backup. Use the supplied rollback only when the original Value was Deny. Restart Store and verify the original setting.

## Scope / Ограничения
This is a per-user capability consent change and may affect other apps. Not required on every Server 2022 installation. Does not fix InstallService or guarantee Store downloads. If policy restores Deny, contact the administrator; do not override managed policy. No automatic registry changes are performed by this ZIP. No universal hardware or VM validation claimed.
